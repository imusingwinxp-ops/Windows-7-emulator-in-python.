import tkinter as tk
from tkinter import messagebox

# Button click handler for calculator
def on_click(event):
    text = event.widget.cget("text")
    if text in ["MC", "MR", "MS", "M+", "M-", "CE", "√", "%", "1/x"]:
        messagebox.showerror("Calc.exe", f"'{text}' button is not functional.")
    elif text == "=":
        try:
            result = eval(str(display.get()))
            display.set(result)
        except Exception as e:
            display.set("result")
    elif text == "C":
        display.set("")
    elif text == "←":
        current = display.get()
        display.set(current[:-1])  # Remove the last character
    else:
        display.set(display.get() + text)

# Error handler for View and Edit menu items
def menu_error(menu_name):
    messagebox.showerror("Calculator", f"'{menu_name}' is not functional.")

# "About" option handler in Help menu
def show_about():
    messagebox.showinfo("About Calculator", "Microsoft Windows Calculator\nLicensed to DODIAB\n2008 Microsoft Corporation.")

# Initialize the Tkinter root window
root = tk.Tk()
root.title("Calculator")
root.geometry("400x600")
root.resizable(False, False)

# Create the menu
menu_bar = tk.Menu(root)
root.config(menu=menu_bar)

# Add "View" and "Edit" menu items that give errors
menu_bar.add_command(label="View", command=lambda: menu_error("View"))
menu_bar.add_command(label="Edit", command=lambda: menu_error("Edit"))

# Add "Help" menu with dropdown options
help_menu = tk.Menu(menu_bar, tearoff=0)
help_menu.add_command(label="About", command=show_about)
menu_bar.add_cascade(label="Help", menu=help_menu)

# Main display area
display = tk.StringVar()
display.set("0")
entry = tk.Entry(root, textvar=display, font="Arial 24", bd=10, relief="sunken", justify="right")
entry.grid(row=0, column=0, columnspan=4, sticky="we", padx=10, pady=10)

# Button layout
buttons = [
    ["MC", "MR", "MS", "M+"],
    ["M-", "←", "CE", "C"],
    ["7", "8", "9", "/"],
    ["4", "5", "6", "*"],
    ["1", "2", "3", "-"],
    ["0", ".", "=", "+"],
]

special_buttons = ["√", "%", "1/x"]

# Add buttons to the calculator
for i, row in enumerate(buttons):
    for j, btn in enumerate(row):
        action = tk.Button(
            root, text=btn, font="Arial 18", relief="raised", width=5, height=2, bg="yellow" if btn in special_buttons else "white"
        )
        action.grid(row=i + 1, column=j, padx=5, pady=5)
        action.bind("<Button-1>", on_click)

# Run the Tkinter event loop
root.mainloop()
