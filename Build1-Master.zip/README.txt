Please extract the folder first before running.
Built for Python 3.14.6.
Requires Pillow and Pygame-CE.