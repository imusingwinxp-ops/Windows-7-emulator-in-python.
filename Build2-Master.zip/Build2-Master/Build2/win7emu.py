#Added several upgrades to the original code from 2023 for python 3.10, like support for the more modern 3.14.5 and above, and ensured that the code is portable. Also set the startup screen to have the text printed in the middle of the screen, instead of using coordinates, to ensure that the screen is good on different resolutions. The next revision of the code will ensure that the login screen has the image background modified to fit all screens.
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import pygame
import os
import subprocess
import sys

# Portable paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESOURCES_DIR = os.path.join(BASE_DIR, "resources")
PROGRAMS_DIR = os.path.join(BASE_DIR, "programs")

#Startin windows screen
class StartingWindowsScreen:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Windows 7 emulator")
        self.window.configure(bg='#0A0A0A')

        #Fullscreen
        self.fullscreen = True
        self.window.attributes('-fullscreen', True)
        self.window.bind("<f>", self.toggle_fullscreen)

        #Starting windows text
        tk.Label(
            self.window,
            text="Starting Windows",
            bg='#0A0A0A',
            fg='white',
            font=("Segoe UI", 18)
        ).place(relx=0.5, rely=0.5, anchor='center')

        tk.Label(
            self.window,
            text='© Microsoft Coorporation',
            bg='#0A0A0A',
            fg='white',
            font=("Segoe UI", 10)
        ).place(relx=0.5, rely=0.68, anchor='center')

        self.window.after(4000, self.exit_program)

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.window.attributes("-fullscreen", self.fullscreen)

    def exit_program(self):
       self.window.destroy()
       app = LoginWindow()
       app.main()

    def main(self):
        self.window.mainloop()


# Login Window Class
class LoginWindow:
    def __init__(self, master=None, username="DODIAB"):
        self.master = master or tk.Tk()
        self.username = username
        self.fullscreen = True
        self.master.title("Windows 7 Login")
        self.master.geometry('1500x1500')

        self.background_image_path = os.path.join(RESOURCES_DIR, "login.jpg")
        self.profile_image_path = os.path.join(RESOURCES_DIR, "profpic.png")
        self.startup_sound_path = os.path.join(RESOURCES_DIR, "startupsnd.mp3")

        # Initialize pygame mixer
        pygame.mixer.init()

        self.create_widgets()
        self.master.bind("<f>", self.toggle_fullscreen)
        self.master.attributes('-fullscreen', True)
        self.play_startup_sound()

    def create_widgets(self):
        # Load the background image
        try:
            self.background_image = Image.open(self.background_image_path)
            self.background_photo = ImageTk.PhotoImage(self.background_image)
            self.background_label = tk.Label(self.master, image=self.background_photo)
            self.background_label.place(x=0, y=0, relwidth=1, relheight=1)
        except Exception as e:
            print(f"Error loading background image: {e}")

        # Create login frame
        frame = tk.Frame(self.master, bg='#357EC9')
        frame.place(relx=0.5, rely=0.5, anchor='center')

        # Load the profile picture
        try:
            self.profile_image = Image.open(self.profile_image_path)
            self.profile_photo = ImageTk.PhotoImage(self.profile_image)
            profile_label = tk.Label(frame, image=self.profile_photo, bg='#357EC9')
            profile_label.grid(row=0, column=0, columnspan=2, pady=10)
        except Exception as e:
            print(f"Error loading profile picture: {e}")

        # Login fields and buttons
        login_label = tk.Label(frame, text=self.username, bg='#357EC9', fg="#FFFFFF", font=("Segoe UI", 20))
        password_label = tk.Label(frame, text="Password:", bg='#357EC9', fg="#FFFFFF", font=("Segoe UI", 16))
        self.password_entry = tk.Entry(frame, show="*", font=("Segoe UI", 16))
        login_button = tk.Button(frame, text="Login", bg="#357EC9", fg="#FFFFFF", font=("Segoe UI", 16), command=self.login)
        switch_user_button = tk.Button(frame, text="Switch User", bg="#357EC9", fg="#FFFFFF", font=("Segoe UI", 16), command=self.switch_user)

        login_label.grid(row=1, column=0, columnspan=2, pady=10)
        password_label.grid(row=2, column=0, pady=10)
        self.password_entry.grid(row=2, column=1, pady=10)
        login_button.grid(row=3, column=0, columnspan=2, pady=20)
        switch_user_button.grid(row=4, column=0, columnspan=2, pady=10)

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.master.attributes("-fullscreen", self.fullscreen)

    def play_startup_sound(self):
        try:
            pygame.mixer.music.load(self.startup_sound_path)
            pygame.mixer.music.play()
        except Exception as e:
            print(f"Error playing startup sound: {e}")

    def open_desktop(self):
        self.master.destroy()
        app = Windows7Desktop()
        app.main()

    def login(self):
        # Define passwords for each user
        if self.username == "DODIAB":
            correct_password = "Mrbean6000!"
        elif self.username == "Administrator":
            correct_password = "1loveQuanphys!!!!!"
        else:
            correct_password = ""

        if self.password_entry.get() == correct_password:
            messagebox.showinfo("", "Welcome")
            self.master.after(1000, self.open_desktop)
        else:
            messagebox.showerror("", "Incorrect Username or Password")

    def switch_user(self):
        # Toggle between 'DODIAB' and 'Administrator'
        if self.username == "DODIAB":
            self.username = "Administrator"
        else:
            self.username = "DODIAB"
        self.create_widgets()  # Recreate the UI with the new username

    def main(self):
        self.master.attributes('-fullscreen', True)  # Ensure fullscreen mode is set at startup
        self.master.mainloop()


# Windows 7 Desktop Class
class Windows7Desktop:
    def __init__(self, master=None):
        self.master = master or tk.Tk()
        self.fullscreen = True
        self.start_menu_window = None  # Track the Start Menu window
        self.master.title("Windows 7 Desktop")
        self.master.geometry("1500x1500")

        self.background_image_path = os.path.join(RESOURCES_DIR, "desktop.png")
        self.start_button_image_path = os.path.join(RESOURCES_DIR, "startbutton.png")
        self.my_computer_image_path = os.path.join(RESOURCES_DIR, "mycom.jpg")
        self.recycle_bin_image_path = os.path.join(RESOURCES_DIR, "bin.webp")

        self.create_widgets()
        self.master.bind("<f>", self.toggle_fullscreen)
        self.master.bind("<Button-3>", self.show_bsod)
        self.master.attributes('-fullscreen', True)

    def create_widgets(self):
        # Load the background image
        try:
            self.background_image = Image.open(self.background_image_path)
            self.background_photo = ImageTk.PhotoImage(self.background_image)
            self.desktop_bg = tk.Label(self.master, image=self.background_photo)
            self.desktop_bg.place(x=0, y=0, relwidth=1, relheight=1)
        except Exception as e:
            print(f"Error loading desktop background: {e}")

        # Taskbar
        self.taskbar = tk.Frame(self.master, bg="light blue", height=40)
        self.taskbar.pack(side=tk.BOTTOM, fill=tk.X)

        # Load the start button and menu.
        try:
            self.start_button_image = Image.open(self.start_button_image_path)
            self.start_button_photo = ImageTk.PhotoImage(self.start_button_image)
            self.start_button = tk.Button(self.taskbar, image=self.start_button_photo, command=self.toggle_start_menu, borderwidth=0)
            self.start_button.pack(side=tk.LEFT, padx=10, pady=5)
        except Exception as e:
            print(f"Error loading start button: {e}")

        # Load and resize "My Computer" image
        try:
            self.my_computer_image = Image.open(self.my_computer_image_path)
            self.my_computer_image = self.my_computer_image.resize((64, 64), Image.LANCZOS)
            self.my_computer_photo = ImageTk.PhotoImage(self.my_computer_image)
            self.icon1_button = tk.Button(self.master, image=self.my_computer_photo, command=self.open_my_computer, borderwidth=0)
            self.icon1_button.place(x=50, y=100)
            tk.Label(self.master, text="My Computer", bg="light gray", font=("Segoe UI", 10)).place(x=50, y=170)
        except Exception as e:
            print(f"Error loading 'My Computer' image: {e}")

        # Load and resize "Recycle Bin" image
        try:
            self.recycle_bin_image = Image.open(self.recycle_bin_image_path)
            self.recycle_bin_image = self.recycle_bin_image.resize((64, 64), Image.LANCZOS)
            self.recycle_bin_photo = ImageTk.PhotoImage(self.recycle_bin_image)
            self.icon2_button = tk.Button(self.master, image=self.recycle_bin_photo, command=self.open_recycle_bin, borderwidth=0)
            self.icon2_button.place(x=50, y=200)
            tk.Label(self.master, text="Recycle Bin", bg="light gray", font=("Segoe UI", 10)).place(x=50, y=270)
        except Exception as e:
            print(f"Error loading 'Recycle Bin' image: {e}")

        # Winver button
        winver_button = tk.Button(self.master, text="Winver", bg="light gray", command=self.open_winver)
        winver_button.place(x=50, y=300)

    def toggle_start_menu(self):
        """Toggle the Start Menu visibility."""
        if hasattr(self, 'start_menu_frame') and self.start_menu_frame.winfo_exists():
            # If the Start Menu exists and is visible, close it
            self.close_start_menu()
        else:
            # Otherwise, open it
            self.open_start_menu()

    def open_music(self):
        """Open Windows Media Player (wmplayer)."""
        try:
            # Use subprocess to launch Windows Media Player
            subprocess.Popen([r"C:\Program Files (x86)\Windows Media Player\wmplayer.exe"])
        except FileNotFoundError:
            messagebox.showerror("Error", "Windows Media Player not found.")
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {e}")
            
    def open_calculator(self):
        """Open the custom Python Calculator application."""
        try:
            # Use subprocess to run the Python file
            calc_path = os.path.join(RESOURCES_DIR, "calc.py")
            subprocess.Popen([sys.executable, calc_path])
        except FileNotFoundError:
            messagebox.showerror("Error", r"Calculator not found at \calc.py.")
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {e}")
            

    def open_start_menu(self):
        """Open the Start Menu above the taskbar."""
        self.start_menu_frame = tk.Frame(self.master, bg="white", borderwidth=2, relief="raised")
        self.start_menu_frame.place(x=10, y=self.master.winfo_height() - 440, width=300, height=400)  # Positioned just above the taskbar

        # Dummy Start Menu options with specific commands
        menu_options = [
            ("Getting Started", self.show_error_message),
            ("Calculator", self.open_calculator),
            ("Sticky Notes", self.show_error_message),
            ("Pictures", self.show_error_message),
            ("Music", self.open_music),
            ("Documents", self.show_error_message),
            ("Games", self.show_error_message),
            ("My Computer", self.open_my_computer)  # Opens the same My Computer window
        ]

        for option, command in menu_options:
            btn = tk.Button(
                self.start_menu_frame,
                text=option,
                bg="white",
                font=("Segoe UI", 10),
                command=command
            )
            btn.pack(anchor="w", padx=10, pady=5)

    def show_error_message(self):
        """Show an error message when a Start Menu button is clicked."""
        messagebox.showerror(
            title="TI10657300D(C:)",
            message="Unable to read from drive: C:. Please contact your system administrator.")

    def close_start_menu(self):
        """Close the Start Menu."""
        if hasattr(self, 'start_menu_frame') and self.start_menu_frame.winfo_exists():
            self.start_menu_frame.destroy()

        
    def open_my_computer(self):
        my_computer_window = tk.Toplevel(self.master)
        my_computer_window.title("My Computer")
        my_computer_window.geometry("800x600")
        my_computer_window.state('zoomed')
        tk.Label(my_computer_window, text="Unable to read from drive: 'C:'. Please run the Chkdsk utility.", font=("Segoe UI", 10)).place(x=25, y=50)

    def open_recycle_bin(self):
        recycle_bin = tk.Toplevel(self.master)
        recycle_bin.title("Recycle Bin")
        recycle_bin.geometry("800x600")
        recycle_bin.state('zoomed')
        tk.Label(recycle_bin, text="This folder is empty.", font=("Segoe UI", 10)).place(x=25, y=50)

    def open_winver(self):
        messagebox.showinfo(title="About Windows", message="Microsoft Windows 7\nLicensed to DODIAB\n2002 Microsoft Corporation.")

    def show_bsod(self, event=None):
        self.master.destroy()  # Close the main window

        # Open BSOD window
        self.bsod_window = tk.Toplevel()
        self.bsod_window.title("Windows 7 - Blue Screen of Death (BSOD)")
        self.bsod_window.geometry("1500x1500")
        self.bsod_window.configure(bg="#0827F5")
        self.bsod_window.attributes('-fullscreen', True)

        def toggle_bsod_fullscreen(event):
            fullscreen_state = self.bsod_window.attributes("-fullscreen")
            if fullscreen_state:
                self.bsod_window.attributes("-fullscreen", False)
            else:
                self.bsod_window.attributes("-fullscreen", True)

        # Bind 'f' key to toggle fullscreen for BSOD window
        self.bsod_window.bind("<f>", toggle_bsod_fullscreen)

        bsod_label = tk.Label(self.bsod_window, text="",
                              bg="#0827F5", fg="white", font=("Segoe UI", 16))
        bsod_label.pack(pady=20)

        bsod_message = tk.Label(self.bsod_window, text="PAGE_FAULT_IN_NONPAGED_AREA\n\nIf this is the first time you've seen this stop error screen, \nrestart your computer. If this screen appears again, \nfollow these steps:\n\nCheck to make sure any new hardware or software is properly installed.\nIf this is a new installation, ask your hardware or software manufacturer\nfor any Windows updates you might need.\n\nIf problems continue, disable or remove any newly installed hardware \nor software. Disable BIOS memory options such as caching or shadowing.\nIf you need to use Safe Mode to remove or disable components, restart\nyour computer, press F8 to select Advanced Startup Options, and then\nselect Safe Mode.\n\nTechnical information:\n\n*** STOP: 0x00000050 (0xFD3094C2, 0x00000001, 0xFBFE7617, 0x00000000)\n\n*** ntfs.sys - Address FBFE7617 base at FBFE5000, DateStamp 3d6e5c1c",
                                bg="#0827F5", fg="white", font=("Segoe UI", 12))
        bsod_message.pack(pady=20)

        def exit_program():
            self.bsod_window.destroy()
            self.master.quit()  # Quit the main Tkinter event loop

        bsod_button = tk.Button(self.bsod_window, text="Exit Windows", command=exit_program)
        bsod_button.pack(pady=20)

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.master.attributes("-fullscreen", self.fullscreen)

    def main(self):
        self.master.attributes('-fullscreen', True)
        self.master.mainloop()


if __name__ == "__main__":
    # Start the application
    app = StartingWindowsScreen()
    app.main()

