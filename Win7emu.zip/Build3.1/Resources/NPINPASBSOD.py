import tkinter as tk


class BSODScreen:
    def __init__(self, return_callback=None):
        self.return_callback = return_callback

        self.window = tk.Tk()
        self.window.title("Windows")
        self.window.configure(bg="blue")
        self.window.attributes("-fullscreen", True)

        # bind AFTER window exists
        self.window.bind("<Key>", self.close)
        self.window.bind("<Escape>", self.close)

        text = (
            "A problem has been detected and Windows will now shut down to prevent damage\n"
            "to your computer.\n\n"
            "If this is the first time you've seen this Stop error screen, restart your\n"
            "computer. If this screen appears again, follow these steps:\n\n"
            "Check to make sure any new hardware or software is properly installed.\n"
            "If this is a new installation, ask your hardware or software manufacturer\n"
            "for any Windows updates you might need.\n\n"
            "If problems continue, disable or remove any newly installed hardware or software.\n"
            "Disable BIOS memory options such as caching or shadowing. If you need to use\n"
            "Safe Mode to remove or disable components, restart your computer, press F8 to\n"
            "select Advanced Startup Options, and then select Safe Mode.\n\n"
            "Technical information:\n\n"
            "*** STOP: 0x0000007B (0xFFFFF880009A9928, 0xFFFFFFFFC0000034, 0x0000000000000000)\n\n"
            "*** ntoskrnl.exe - Address FFFFF80002E6A1C0 base at FFFFF80002E00000\n"
            "DateStamp 4a5bc1e2"
        )

        tk.Label(
            self.window,
            text=text,
            fg="white",
            bg="blue",
            font=("Consolas", 12),
            justify="left",
            anchor="nw"
        ).pack(padx=40, pady=40, anchor="nw")

        self.window.bind("<Escape>", self.close)

    def close(self, event=None):
        self.window.destroy()
        if self.return_callback:
            self.return_callback()

    def main(self):
        self.window.mainloop()


if __name__ == "__main__":
    app = BSODScreen()
    app.main()
