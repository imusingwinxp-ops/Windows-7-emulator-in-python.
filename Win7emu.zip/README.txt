Alpha 3.1.1

Please extract the folder first before running.
Built for Python 3.14.6.
Requires Pillow and Pygame-CE.
For the best experience, please run in 1920X1080 resolution with 100% scaling. If you have a different resolution, the start menu may not appear in the correct position.