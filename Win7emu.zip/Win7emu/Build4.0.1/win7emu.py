#Set the start button to be the actual start button, rather than the Windows Media centre button, and added a small segment of code to allow this to be the correct sizing.
#For the best experience, please run in 1920X1080 resolution with 100% scaling. If you have a different resolution, the start menu may not appear in the correct position.
#BUILD 4.0.1

from concurrent.futures import process
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import pygame
import os
import subprocess
import sys
import shutil
import atexit

from pygame import event


# Portable paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

RESOURCES_DIR = os.path.join(BASE_DIR, "resources")

PYCACHE_DIR = os.path.join(RESOURCES_DIR, "__pycache__")

def cleanup_pycache():
    if os.path.exists(PYCACHE_DIR):
        try:
            shutil.rmtree(PYCACHE_DIR)
            print("Removed resources/__pycache__")
        except Exception as e:
            print(f"Could not remove __pycache__: {e}")

atexit.register(cleanup_pycache)

PROGRAMS_DIR = os.path.join(BASE_DIR, "programs")

sys.path.append(RESOURCES_DIR)

from NPINPABSOD import BSODScreen


# ----------------------------
# Advanced Boot Options
# ----------------------------
class AdvancedOptionsScreen:
    def __init__(self, return_callback, bsod_callback):
        self.return_callback = return_callback
        self.bsod_callback = bsod_callback

        self.window = tk.Tk()
        self.window.title("Advanced Boot Options")
        self.window.configure(bg="black")
        self.window.attributes("-fullscreen", True)

        self.options = [
            "Repair Your Computer",
            "Safe Mode",
            "Safe Mode with Networking",
            "Safe Mode with Command Prompt",
            "Enable Boot Logging",
            "Enable low-resolution video (640x480)",
            "Last Known Good Configuration (advanced)",
            "Directory Services Restore Mode",
            "Debugging Mode",
            "Disable automatic restart on system failure",
            "Disable Driver Signature Enforcement",
            "Start Windows Normally"
        ]

        self.selected_index = 0
        self.fullscreen = True

        self.label = tk.Label(
            self.window,
            fg="white",
            bg="black",
            font=("Courier New", 14),
            justify="left",
            anchor="nw"
        )
        self.label.pack(padx=60, pady=40, anchor="nw")

        self.window.bind("<Up>", self.move_up)
        self.window.bind("<Down>", self.move_down)
        self.window.bind("<Return>", self.select_option)
        self.window.bind("<f>", self.toggle_fullscreen)
        self.window.bind("<Escape>", self.close)

        self.render_menu()

    def render_menu(self):
        text = (
            "Advanced Boot Options\n\n"
            "Use arrow keys to select an option.\n"
            "Press Enter to choose.\n"
            "Press F for fullscreen.\n"
            "Press Esc to return.\n\n"
        )

        for i, option in enumerate(self.options):
            if i == self.selected_index:
                text += f"> {option}\n"
            else:
                text += f"  {option}\n"

        self.label.config(text=text)

    def move_up(self, event=None):
        if self.selected_index > 0:
            self.selected_index -= 1
            self.render_menu()

    def move_down(self, event=None):
        if self.selected_index < len(self.options) - 1:
            self.selected_index += 1
            self.render_menu()

    def select_option(self, event=None):
        option = self.options[self.selected_index]

        self.window.destroy()

        if option == "Start Windows Normally":
            self.return_callback()
        else:
            self.bsod_callback()

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.window.attributes("-fullscreen", self.fullscreen)

    def close(self, event=None):
        self.window.destroy()
        self.return_callback()

    def main(self):
        self.window.mainloop()


# ----------------------------
# Starting Windows Screen
# ----------------------------
class StartingWindowsScreen:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Windows 7 emulator")
        self.window.configure(bg='#0A0A0A')

        self.fullscreen = True
        self.window.attributes('-fullscreen', True)

        self.window.bind("<F8>", self.open_advanced_options)
        self.window.bind("<f>", self.toggle_fullscreen)

        tk.Label(
            self.window,
            text="Starting Windows",
            bg='#0A0A0A',
            fg='white',
            font=("Segoe UI", 18)
        ).place(relx=0.5, rely=0.5, anchor='center')

        tk.Label(
            self.window,
            text='© Microsoft Corporation',
            bg='#0A0A0A',
            fg='white',
            font=("Segoe UI", 10)
        ).place(relx=0.5, rely=0.68, anchor='center')

        self.boot_timer = self.window.after(5000, self.exit_program)

    def open_advanced_options(self, event=None):
        if hasattr(self, "boot_timer"):
            self.window.after_cancel(self.boot_timer)

        self.window.destroy()

        AdvancedOptionsScreen(
            return_callback=self.restart_boot_screen,
            bsod_callback=self.show_bsod
        ).main()

    def show_bsod(self):
        BSODScreen(self.restart_boot_screen).main()

    def restart_boot_screen(self):
        self.__init__()
        self.main()

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.window.attributes("-fullscreen", self.fullscreen)

    def exit_program(self):
        self.window.destroy()
        app = LoginWindow()
        app.main()

    def main(self):
        self.window.mainloop()




# Login Window Class
class LoginWindow:
    def __init__(self, master=None, username="DODIAB"):
        self.master = master or tk.Tk()
        self.username = username
        self.fullscreen = True
        self.master.title("Windows 7 Login")
        self.master.geometry('1500x1500')

        self.background_image_path = os.path.join(RESOURCES_DIR, "login.jpg")
        self.profile_image_path = os.path.join(RESOURCES_DIR, "profpic.png")
        self.startup_sound_path = os.path.join(RESOURCES_DIR, "startupsnd.mp3")

        # Initialize pygame mixer
        pygame.mixer.init()

        self.create_widgets()
        self.master.bind("<f>", self.toggle_fullscreen)
        self.master.attributes('-fullscreen', True)
        self.play_startup_sound()

    def create_widgets(self):
        # ==============================
        # LOGIN BACKGROUND
        # ==============================
        try:
            screen_width = self.master.winfo_screenwidth()
            screen_height = self.master.winfo_screenheight()

            image = Image.open(self.background_image_path)

            # Keep the aspect ratio while making sure
            # the entire screen is covered.
            img_width, img_height = image.size

            scale = max(
                screen_width / img_width,
                screen_height / img_height
            )

            new_width = int(img_width * scale)
            new_height = int(img_height * scale)

            image = image.resize(
                (new_width, new_height),
                Image.LANCZOS
            )

            # Crop the excess from the sides/top.
            left = (new_width - screen_width) // 2
            top = (new_height - screen_height) // 2

            image = image.crop(
                (
                    left,
                    top,
                    left + screen_width,
                    top + screen_height
                )
            )

            self.background_photo = ImageTk.PhotoImage(image)

            self.background_label = tk.Label(
                self.master,
                image=self.background_photo,
                borderwidth=0
            )

            self.background_label.place(
                x=0,
                y=0,
                relwidth=1,
                relheight=1
            )

            # Keep background behind everything
            self.background_label.lower()

        except Exception as e:
            print(f"Error loading login background: {e}")

        # ==============================
        # LOGIN FRAME
        # ==============================
        frame = tk.Frame(
            self.master,
            bg="#357EC9"
        )

        frame.place(
            relx=0.5,
            rely=0.5,
            anchor="center"
        )

        frame.lift()

        # ==============================
        # PROFILE PICTURE
        # ==============================
        try:
            self.profile_image = Image.open(
                self.profile_image_path
            )

            self.profile_photo = ImageTk.PhotoImage(
                self.profile_image
            )

            profile_label = tk.Label(
                frame,
                image=self.profile_photo,
                 bg="#357EC9"
            )

            profile_label.grid(
                row=0,
                column=0,
                columnspan=2,
                pady=10
            )

        except Exception as e:
            print(f"Error loading profile picture: {e}")

        # ==============================
        # LOGIN TEXT
        # ==============================
        login_label = tk.Label(
            frame,
            text=self.username,
            bg="#357EC9",
            fg="#FFFFFF",
            font=("Segoe UI", 20)
        )

        password_label = tk.Label(
            frame,
            text="Password:",
            bg="#357EC9",
            fg="#FFFFFF",
            font=("Segoe UI", 16)
        )

        self.password_entry = tk.Entry(
            frame,
            show="*",
            font=("Segoe UI", 16)
        )

        login_button = tk.Button(
            frame,
            text="Login",
            bg="#357EC9",
            fg="#FFFFFF",
            font=("Segoe UI", 16),
            command=self.login
        )

        switch_user_button = tk.Button(
            frame,
            text="Switch User",
            bg="#357EC9",
            fg="#FFFFFF",
            font=("Segoe UI", 16),
            command=self.switch_user
        )

        login_label.grid(
            row=1,
            column=0,
            columnspan=2,
            pady=10
        )

        password_label.grid(
            row=2,
            column=0,
            pady=10
        )

        self.password_entry.grid(
            row=2,
            column=1,
             pady=10
        )

        login_button.grid(
            row=3,
            column=0,
            columnspan=2,
            pady=20
        )

        switch_user_button.grid(
            row=4,
            column=0,
            columnspan=2,
            pady=10
        )

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.master.attributes("-fullscreen", self.fullscreen)

    def play_startup_sound(self):
        try:
            pygame.mixer.music.load(self.startup_sound_path)
            pygame.mixer.music.play()
        except Exception as e:
            print(f"Error playing startup sound: {e}")

    def open_desktop(self):
        self.master.destroy()
        app = Windows7Desktop()
        app.main()

    def login(self):
        # Define passwords for each user
        if self.username == "DODIAB":
            correct_password = "Mrbean6000!"
        elif self.username == "Administrator":
            correct_password = "1loveQuanphys!!!!!"
        else:
            correct_password = ""

        if self.password_entry.get() == correct_password:
            messagebox.showinfo("", "Welcome")
            self.master.after(1000, self.open_desktop)
        else:
            messagebox.showerror("", "Incorrect Username or Password")

    def switch_user(self):
        # Toggle between 'DODIAB' and 'Administrator'
        if self.username == "DODIAB":
            self.username = "Administrator"
        else:
            self.username = "DODIAB"
        self.create_widgets()  # Recreate the UI with the new username

    def main(self):
        self.master.attributes('-fullscreen', True)  # Ensure fullscreen mode is set at startup
        self.master.mainloop()


# Windows 7 Desktop Class
class Windows7Desktop:
    def __init__(self, master=None):
        self.master = master or tk.Tk()
        self.fullscreen = True
        self.start_menu_window = None

        self.master.title("Windows 7 Desktop")
        self.master.geometry("1500x1500")
        self.master.attributes('-fullscreen', True)

        self.background_image_path = os.path.join(RESOURCES_DIR, "desktop.png")
        self.start_button_image_path = os.path.join(RESOURCES_DIR, "startbutton.png")
        self.my_computer_image_path = os.path.join(RESOURCES_DIR, "mycom.jpg")
        self.recycle_bin_image_path = os.path.join(RESOURCES_DIR, "bin.webp")

        self.create_widgets()

        self.master.bind("<f>", self.toggle_fullscreen)

        self.setup_context_menu()

        self.master.bind("<Button-3>", self.show_context_menu)

    def _toggle_shutdown_fullscreen(self, win):
        current = win.attributes("-fullscreen")
        win.attributes("-fullscreen", not current)

    def shutdown_sequence(self):
        import os, shutil

        shutdown_win = tk.Toplevel(self.master)
        shutdown_win.attributes("-fullscreen", True)
        shutdown_win.attributes("-topmost", True)

        shutdown_sound_path = os.path.join(
            RESOURCES_DIR,
            "shutdnsnd.mp3"
        )

        try:
            pygame.mixer.music.load(shutdown_sound_path)
            pygame.mixer.music.play()
        except Exception as e:
             print(f"Error playing shutdown sound: {e}")

        shutdown_win.focus_force()
        shutdown_win.bind("<KeyPress-f>", lambda e: self._toggle_shutdown_fullscreen(shutdown_win))


        img_path = os.path.join(RESOURCES_DIR, "shutdownimg.png")

        try:
            from PIL import Image, ImageTk

            img = Image.open(img_path)

            screen_w = shutdown_win.winfo_screenwidth()
            screen_h = shutdown_win.winfo_screenheight()

            img = img.resize((screen_w, screen_h), Image.LANCZOS)

            photo = ImageTk.PhotoImage(img)

            label = tk.Label(shutdown_win, image=photo)
            label.image = photo
            label.pack(fill="both", expand=True)

        except Exception:
            tk.Label(
                shutdown_win,
                text="Shutting down...",
                font=("Segoe UI", 30)
            ).pack(expand=True)

        # force render
        shutdown_win.update()

        # wait 5 seconds
        shutdown_win.after(3700, lambda: self._final_shutdown(shutdown_win))

    def _final_shutdown(self, window):
        import os, shutil

        try:
            window.destroy()
        except:
            pass

        # cleanup cache
        cache_dir = os.path.join(RESOURCES_DIR, "__pycache__")
        if os.path.exists(cache_dir):
            shutil.rmtree(cache_dir, ignore_errors=True)

        os._exit(0)

    def run_bsod_then_exit(self, bsod_file):
        import sys, subprocess, os, shutil

        self.master.destroy()

        bsod_path = os.path.join(RESOURCES_DIR, bsod_file)
        process = subprocess.Popen([sys.executable, bsod_path])
        process.wait()

        # remove cache folder inside resources
        cache_dir = os.path.join(RESOURCES_DIR, "__pycache__")
        if os.path.exists(cache_dir):
            shutil.rmtree(cache_dir, ignore_errors=True)

        os._exit(0)

    def fake_error(self):
        messagebox.showerror(
            title="TI10657300D(C:)",
            message="Unable to read from drive: C:. Please contact your system administrator."
        )

    def create_widgets(self):
        # Load the background image
        try:
            self.background_image = Image.open(self.background_image_path)
            self.background_photo = ImageTk.PhotoImage(self.background_image)
            self.desktop_bg = tk.Label(self.master, image=self.background_photo)
            self.desktop_bg.place(x=0, y=0, relwidth=1, relheight=1)
        except Exception as e:
            print(f"Error loading desktop background: {e}")

        # Taskbar
        self.taskbar = tk.Frame(self.master, bg="light blue", height=40)
        self.taskbar.pack(side=tk.BOTTOM, fill=tk.X)

        # Load the start button and menu.
        try:
            self.start_button_image = Image.open(self.start_button_image_path)
            self.start_button_image = self.start_button_image.resize((45, 45), Image.LANCZOS)
            self.start_button_photo = ImageTk.PhotoImage(self.start_button_image)
            self.start_button = tk.Button(self.taskbar, image=self.start_button_photo, command=self.toggle_start_menu, borderwidth=0)
            self.start_button.pack(side=tk.LEFT, padx=10, pady=5)
        except Exception as e:
            print(f"Error loading start button: {e}")

        # Load and resize "My Computer" image
        try:
            self.my_computer_image = Image.open(self.my_computer_image_path)
            self.my_computer_image = self.my_computer_image.resize((64, 64), Image.LANCZOS)
            self.my_computer_photo = ImageTk.PhotoImage(self.my_computer_image)
            self.icon1_button = tk.Button(self.master, image=self.my_computer_photo, command=self.open_my_computer, borderwidth=0)
            self.icon1_button.place(x=50, y=100)
            tk.Label(self.master, text="My Computer", bg="light gray", font=("Segoe UI", 10)).place(x=50, y=170)
        except Exception as e:
            print(f"Error loading 'My Computer' image: {e}")

        # Load and resize "Recycle Bin" image
        try:
            self.recycle_bin_image = Image.open(self.recycle_bin_image_path)
            self.recycle_bin_image = self.recycle_bin_image.resize((64, 64), Image.LANCZOS)
            self.recycle_bin_photo = ImageTk.PhotoImage(self.recycle_bin_image)
            self.icon2_button = tk.Button(self.master, image=self.recycle_bin_photo, command=self.open_recycle_bin, borderwidth=0)
            self.icon2_button.place(x=50, y=200)
            tk.Label(self.master, text="Recycle Bin", bg="light gray", font=("Segoe UI", 10)).place(x=50, y=270)
        except Exception as e:
            print(f"Error loading 'Recycle Bin' image: {e}")

        # Winver button
        winver_button = tk.Button(self.master, text="Winver", bg="light gray", command=self.open_winver)
        winver_button.place(x=50, y=300)

    def toggle_start_menu(self):
        """Toggle the Start Menu visibility."""
        if hasattr(self, 'start_menu_frame') and self.start_menu_frame.winfo_exists():
            # If the Start Menu exists and is visible, close it
            self.close_start_menu()
        else:
            # Otherwise, open it
            self.open_start_menu()

    def open_music(self):
        """Open Windows Media Player (wmplayer)."""
        try:
            # Use subprocess to launch Windows Media Player
            subprocess.Popen([r"C:\Program Files (x86)\Windows Media Player\wmplayer.exe"])
        except FileNotFoundError:
            messagebox.showerror("Error", "Windows Media Player not found.")
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {e}")
            
    def open_calculator(self):
        """Open the custom Python Calculator application."""
        try:
            # Use subprocess to run the Python file
            calc_path = os.path.join(RESOURCES_DIR, "calc.py")
            subprocess.Popen([sys.executable, calc_path])
        except FileNotFoundError:
            messagebox.showerror("Error", r"Calculator not found at \calc.py.")
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {e}")
            

    def open_start_menu(self):
        """Open the Start Menu above the taskbar."""
        self.start_menu_frame = tk.Frame(
            self.master,
            bg="white",
            borderwidth=2,
            relief="raised"
        )

        self.start_menu_frame.bind(
            "<Button-3>",
            lambda e: "break"
        )

        self.start_menu_frame.place(
            x=10,
            y=self.master.winfo_height() - 500,
            width=300,
            height=450
        )

        menu_options = [
            ("Getting Started", self.show_error_message),
            ("Calculator", self.open_calculator),
            ("Sticky Notes", self.show_error_message),
            ("Pictures", self.show_error_message),
            ("Music", self.open_music),
            ("Documents", self.show_error_message),
            ("Games", self.show_error_message),
            ("My Computer", self.open_my_computer)
        ]

        for option, command in menu_options:
            btn = tk.Button(
                self.start_menu_frame,
                text=option,
                bg="white",
                font=("Segoe UI", 10),
                command=command
            )
            btn.pack(anchor="w", padx=10, pady=5)

        # Bottom bar
        bottom_frame = tk.Frame(
            self.start_menu_frame,
            bg="#E8EEF7",
            height=35
        )
        bottom_frame.pack(
            side=tk.BOTTOM,
            fill=tk.X,
            pady=5
        )
        bottom_frame.pack_propagate(False)

        # Arrow button
        arrow_button = tk.Button(
            bottom_frame,
            text="▶",
            font=("Segoe UI", 10),
            width=2
        )
        arrow_button.pack(
            side=tk.RIGHT,
            pady=2
        )

        arrow_button.bind(
            "<Enter>",
            self.show_power_menu
        )


        # Shut down button
        shutdown_button = tk.Button(
            bottom_frame,
            text="Shut down",
            font=("Segoe UI", 10),
            command=self.shutdown_sequence
        )
        shutdown_button.pack(
            side=tk.RIGHT,
            padx=(0, 5),
            pady=2
        )

    def run_power_bsod(self):
        self.master.destroy()

        bsod_path = os.path.join(RESOURCES_DIR, "NPINPASBSOD.py")
        subprocess.Popen([sys.executable, bsod_path])

        os._exit(0)  # IMPORTANT: stop emulator completely

    def show_power_menu(self, event=None):
        power_menu = tk.Menu(self.master, tearoff=0)

        power_menu.add_command(
            label="Sleep",
            command=lambda: self.run_bsod_then_exit("NPINPASBSOD.py")
        )
        power_menu.add_command(
            label="Restart",
            command=lambda: self.run_bsod_then_exit("NPINPASBSOD.py")
        )
        power_menu.add_separator()
        power_menu.add_command(
            label="Shut down",
            command=self.shutdown_sequence
        )

        x = event.widget.winfo_rootx()
        y = event.widget.winfo_rooty() + event.widget.winfo_height()

        power_menu.tk_popup(x, y)
        
    def show_bsod_and_restart(self):
        self.master.destroy()

        bsod_path = os.path.join(RESOURCES_DIR, "NPINPABSOD.py")
        subprocess.run([sys.executable, bsod_path])

        
        os.startfile(__file__)  # re-launch script like Windows double-click

    def show_error_message(self):
        messagebox.showerror(
            title="TI10657300D(C:)",
            message="Unable to read from drive: C:. Please contact your system administrator.")

    def close_start_menu(self):
        """Close the Start Menu."""
        if hasattr(self, 'start_menu_frame') and self.start_menu_frame.winfo_exists():
            self.start_menu_frame.destroy()

    def setup_context_menu(self):
        if hasattr(self, "context menu"):
            self.context_menu.tk_popup(event.x_root, event.y_root)
            self.context_menu.grab_release()

        self.context_menu = tk.Menu(self.master, tearoff=0)

        # Refresh (does nothing)
        self.context_menu.add_command(label="Refresh", command=lambda: None)

        # New submenu
        new_menu = tk.Menu(self.context_menu, tearoff=0)

        new_menu.add_command(label="New Folder", command=self.fake_error)
        new_menu.add_command(label="New Text Document", command=self.fake_error)
        new_menu.add_command(label="New Shortcut", command=self.fake_error)

        self.context_menu.add_cascade(label="New", menu=new_menu)

    def show_context_menu(self, event):
        if (
            hasattr(self, "start_menu_frame")
            and self.start_menu_frame.winfo_exists()
            and event.widget.winfo_toplevel() == self.master
        ):
            x1 = self.start_menu_frame.winfo_rootx()
            y1 = self.start_menu_frame.winfo_rooty()
            x2 = x1 + self.start_menu_frame.winfo_width()
            y2 = y1 + self.start_menu_frame.winfo_height()

            # If click is inside Start Menu, do nothing
            if x1 <= event.x_root <= x2 and y1 <= event.y_root <= y2:
                return

        self.context_menu.tk_popup(event.x_root, event.y_root)

        
    def open_my_computer(self):
        my_computer_window = tk.Toplevel(self.master)
        my_computer_window.title("My Computer")
        my_computer_window.geometry("800x600")
        my_computer_window.state('zoomed')
        tk.Label(my_computer_window, text="Unable to read from drive: 'C:'. Please run the Chkdsk utility.", font=("Segoe UI", 10)).place(x=25, y=50)

    def open_recycle_bin(self):
        recycle_bin = tk.Toplevel(self.master)
        recycle_bin.title("Recycle Bin")
        recycle_bin.geometry("800x600")
        recycle_bin.state('zoomed')
        tk.Label(recycle_bin, text="This folder is empty.", font=("Segoe UI", 10)).place(x=25, y=50)

    def open_winver(self):
        messagebox.showinfo(title="About Windows", message="Microsoft Windows 7\nLicensed to DODIAB\n2002 Microsoft Corporation.")

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.master.attributes("-fullscreen", self.fullscreen)

    def main(self):
        self.master.attributes('-fullscreen', True)
        self.master.mainloop()


if __name__ == "__main__":
    # Start the application
    app = StartingWindowsScreen()
    app.main()

