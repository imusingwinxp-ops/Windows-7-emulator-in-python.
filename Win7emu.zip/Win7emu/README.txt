Alpha 4.0.1

Please extract the folder first before running.
Built for Python 3.13.15; may not be fully compatible with 3.14.X and above.
Requires Pillow, Pygame, and Pygame-CE.
For the best experience, please run in 1920X1080 resolution with 100% scaling. If you have a different resolution, the start menu may not appear in the correct position.